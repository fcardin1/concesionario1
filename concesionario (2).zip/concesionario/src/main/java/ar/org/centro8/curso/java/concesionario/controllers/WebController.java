package ar.org.centro8.curso.java.concesionario.controllers;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.curso.java.concesionario.entities.Cliente;
import ar.org.centro8.curso.java.concesionario.entities.Auto;
import ar.org.centro8.curso.java.concesionario.entities.Factura;
import ar.org.centro8.curso.java.concesionario.repositories.ClienteRepository;
import ar.org.centro8.curso.java.concesionario.repositories.AutoRepository;
import ar.org.centro8.curso.java.concesionario.repositories.FacturaRepository;

@Controller
public class WebController {
   //sh mvnw spring-boot:run
    private AutoRepository autoRepository=new AutoRepository();
    private FacturaRepository facturaRepository=new FacturaRepository();
    private ClienteRepository clienteRepository=new ClienteRepository();
    private String mensajeAuto="Ingrese un nuevo Auto!";
    private String mensajeFactura="Ingrese un nuevo Factura!";
    private String mensajeCliente="Ingrese un nuevo Cliente!";

    @GetMapping("/")
    public String getIndex(){
        return "index";
    }

     @GetMapping("/auto")
    public String getAlimento(@RequestParam(name="buscarMarca", required = false, defaultValue="") String buscarMarca,
                                 Model model){
        model.addAttribute("mensajeAuto", mensajeAuto);
        model.addAttribute("Auto", new Auto());
        model.addAttribute("likeMarca", autoRepository.getLikeMarca(buscarMarca));
        return "auto";
    }
     @GetMapping("/cliente")
    public String getClientes(@RequestParam(name="buscarApellido", required = false, defaultValue="") String buscarApellido,
                    Model model){
        model.addAttribute("mensajeCliente", mensajeCliente);
        model.addAttribute("cliente", new Cliente());
        model.addAttribute("likeApellido", clienteRepository.getLikeApellido(buscarApellido));
       // model.addAttribute("factura", facturaRepository.getAll());
        return "cliente";
    }
     @GetMapping("/factura")
    public String getFactura(@RequestParam(name="buscarLetra", required = false, defaultValue="") String buscarLetra,
                                 Model model){
        model.addAttribute("mensajeFactura", mensajeFactura);
        model.addAttribute("Factura", new Factura());
        model.addAttribute("auto", autoRepository.getAll());
        model.addAttribute("cliente", clienteRepository.getAll());
        model.addAttribute("likeletra", facturaRepository.getLikeLetra(buscarLetra));
        return "factura";
    }
    
     @PostMapping("/saveAuto")
    public String save(@ModelAttribute Auto auto){
        try {
            autoRepository.save(auto);
            mensajeAuto="Se guardo el auto codigo: "+auto.getCodigo();
        } catch (Exception e) {
            mensajeAuto="Ocurrio un error";
        }
        return "redirect:auto";
    }

    @PostMapping("/saveCliente")
    public String save(@ModelAttribute Cliente cliente){
        try {
            clienteRepository.save(cliente);
            mensajeCliente="Se guardo el cliente codigo: "+cliente.getCodigo();
        } catch (Exception e) {
            mensajeCliente="Ocurrio un error";
        }
        return "redirect:cliente";
    }

    @PostMapping("/saveFactura")
    public String save(@ModelAttribute Factura factura){
        try {
            facturaRepository.save(factura);
            mensajeFactura="Se guardo la factura numero: "+factura.getNumero();
        } catch (Exception e) {
            mensajeFactura="Ocurrio un error";
        }
        return "redirect:factura";
    }

   
 
}