package ar.org.centro8.curso.java.concesionario.entities;

public class autos {
    
}
