package ar.org.centro8.curso.java.concesionario.test;

import ar.org.centro8.curso.java.concesionario.entities.Auto;
import ar.org.centro8.curso.java.concesionario.entities.Cliente;
import ar.org.centro8.curso.java.concesionario.entities.Factura;
import ar.org.centro8.curso.java.concesionario.repositories.AutoRepository;
import ar.org.centro8.curso.java.concesionario.repositories.ClienteRepository;
import ar.org.centro8.curso.java.concesionario.repositories.FacturaRepository;

public class TestRepository {
   public static void main(String[] args) {
        AutoRepository ar=new AutoRepository();

        Auto Auto=new Auto(6, "Renault", "Logan", 1000000, 1);

        ar.save(Auto);

        System.out.println(Auto);

        ar.getAll().forEach(System.out::println);
        System.out.println("******************************");
        System.out.println(ar.getById(40));
        System.out.println("******************************");
        ar.getLikemarcAuto("Re").forEach(System.out::println);

        ClienteRepository cr=new ClienteRepository();
        Cliente Cliente=new Cliente(6, "pepe", "argento", 33000000);
        cr.save(Cliente);
        System.out.println(Cliente);

        System.out.println("******************************");
        cr.getAll().forEach(System.out::println);
        System.out.println("******************************");
        System.out.println(cr.getById(20));
        System.out.println("******************************");
        cr.getLikeNombre("Pa").forEach(System.out::println);

        FacturaRepository fr=new FacturaRepository();
        Factura Factura=new Factura("A", 12345678, "25/03/1988", 500000, 1);
        fr.save(Factura);
        System.out.println(Factura);

        System.out.println("******************************");
        fr.getAll().forEach(System.out::println);
        System.out.println("******************************");
        System.out.println(fr.getById(30    ));
        System.out.println("******************************");
        cr.getLikeNombre("1111").forEach(System.out::println);
        
   } 
}
