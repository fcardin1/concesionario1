package ar.org.centro8.curso.java.concesionario.test;

import ar.org.centro8.curso.java.concesionario.entities.Auto;
import ar.org.centro8.curso.java.concesionario.entities.Cliente;
import ar.org.centro8.curso.java.concesionario.entities.Factura;
import ar.org.centro8.curso.java.concesionario.repositories.AutoRepository;
import ar.org.centro8.curso.java.concesionario.repositories.ClienteRepository;
import ar.org.centro8.curso.java.concesionario.repositories.FacturaRepository;

public class TestRepository {
   public static void main(String[] args) {
        AutoRepository ar=new AutoRepository();

        Auto Auto=new Auto( "Renault", "Logan", 1000000);

        ar.save(Auto);

        System.out.println(Auto);

        ar.getAll().forEach(System.out::println);
        System.out.println("******************************");
        System.out.println(ar.getById(4));
        System.out.println("******************************");
        ar.getLikeMarca("Re").forEach(System.out::println);

        ClienteRepository cr=new ClienteRepository();
        Cliente Cliente=new Cliente( "pepe", "argento", "33716104");
        cr.save(Cliente);
        System.out.println(Cliente);

        System.out.println("******************************");
        cr.getAll().forEach(System.out::println);
        System.out.println("******************************");
        System.out.println(cr.getById(3));
        System.out.println("******************************");
        cr.getLikeApellido("Pa").forEach(System.out::println);

        FacturaRepository fr=new FacturaRepository();
        Factura Factura=new Factura("A","25/03/1988", 500000);
        fr.save(Factura);
        System.out.println(Factura);

        System.out.println("******************************");
        fr.getAll().forEach(System.out::println);
        System.out.println("******************************");
        System.out.println(fr.getByNumero(3   ));
        System.out.println("******************************");
        cr.getLikeApellido("1111").forEach(System.out::println);

        
        
   } 
}
